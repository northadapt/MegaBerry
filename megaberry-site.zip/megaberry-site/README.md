# MegaBerry website

Plain HTML, CSS and JavaScript. No build step, no dependencies. Open it with any static host.

## Run it locally

```bash
cd megaberry-site
python3 -m http.server 8080
# open http://localhost:8080
```

(Opening `index.html` straight from disk also works, apart from root-absolute links like `/studio`.)

## Structure

```
megaberry-site/
├── index.html            Home
├── studio.html           Signed-in studio home (app shell, not indexed)
├── avatars.html          Identity lock and avatar training
├── showcase.html         Filterable gallery of real output
├── pricing.html          Plans, comparison table, billing FAQ
├── trust.html            Trust & safety
├── faq.html              Searchable FAQ
├── developers.html       Developer API docs (side nav, code tabs, operation filter)
├── contact.html          Sales enquiry form
├── privacy.html          Legal stub (paste real text)
├── terms.html            Legal stub (paste real text)
├── 404.html              Not-found page
├── page-template.html    Copy this to make a new page
├── robots.txt
├── sitemap.xml
└── assets/
    ├── css/
    │   ├── main.css          Entry point; imports the rest in order
    │   ├── tokens.css        Colours, type, spacing, radii
    │   ├── base.css          Reset, element defaults, review-mode switch
    │   ├── layout.css        Header, footer, sections, grids
    │   ├── components.css    Cards, plans, table, FAQ, forms, frames…
    │   ├── pages.css         Page-specific layout (hero, studio mock-up, gallery)
    │   └── docs.css          Documentation layout (developers page)
    ├── js/
    │   ├── layout.js         Header + footer, nav, site config  ← edit this for links/URLs
    │   ├── main.js           Menu, identity tabs, tools demo, FAQ search, filters, form
    │   └── docs.js           Docs behaviour: scroll-spy nav, code tabs, copy buttons, operation filter
    ├── img/                  Images (favicon.svg is the only file so far)
    ├── video/                Showcase clips
    └── fonts/                Reserved for self-hosted fonts
```

## Adding a page

1. Copy `page-template.html` to a new name, e.g. `about.html`.
2. Edit the `<title>`, description and `data-page`.
3. Add it to `NAV` or `FOOTER` in `assets/js/layout.js`, and to `sitemap.xml`.
4. Build the body from the components below.

Sub-folders: put `data-root="../"` on `<body>` and prefix the `assets/…` links with `../`.

## Buttons and glass look (assets/vendor/glass/glass-lite.css)
Buttons use the `gk-btn` classes from the owner's glass-kit (`gk-btn`, `gk-btn--solid`, `gk-btn--lg`, `gk-btn--block`). The soft purple glow behind the page is `.gk-ambient`, injected by `layout.js`. MegaBerry's overrides are at the bottom of `glass-lite.css`.

## Components (assets/css/components.css)

| Need | Class |
| --- | --- |
| Section with a heading | `.section` > `.container` > `.section__head` (+ `.eyebrow`, `h2`, `.lede`) |
| Columns | `.grid .grid--2/3/4`, `.split` (text + media) |
| Buttons | `.btn .btn--primary / --secondary / --ghost`, `--lg`, `--block` |
| Feature / step | `.feature`, `.step` inside `.steps` |
| Card | `.card` |
| Pricing | `.plans` > `.plan` (+ `.plan--featured`) |
| Table | `.table-wrap` > `table.compare` |
| FAQ item | `details.faq__item` > `summary` + `.faq__a` |
| Media placeholder | `.frame .frame--16x9 / 9x16 / 4x5 / 1x1` |
| Closing call to action | `.cta` |
| Capability cards under a hero | `.caps` > `a.cap` (svg + `<b>` + `<span>`) |
| Quickstart step with UI fragment | `.kick` > `.kick__media` (`style="--k:#colour"`) > `.ui` |
| Segmented control / tool chips | `.seg`, `.chip.chip--model` (see the `data-tools` block in `main.js`) |
| Light-on-dark (or dark-on-light) card | `.inverse` > `.inverse__text` + `.inverse__media` |
| Coloured section label / stat numerals | `.eyebrow.hue-violet/blue/teal/coral/pink`, `.stats--hues` |

Change colours, fonts or spacing only in `tokens.css`.

## Adding media

Every dashed, hatched box is a `.frame` placeholder. To use a real image or clip, put the file in `assets/img/` or `assets/video/` and replace the label span:

```html
<div class="frame frame--9x16" data-cat="film">
  <span class="frame__tag">Film</span>
  <video src="assets/video/film-01.mp4" poster="assets/img/film-01.jpg" muted loop playsinline controls></video>
</div>
```

For images use `<img src="…" alt="Describe the image" loading="lazy">`.

## Review mode and launch

Every page has `<html data-review>`. While it is present:

- every dashed **CONFIRM** tag is visible. Each one marks a fact, policy, number or asset that still needs your real content.

To launch, remove `data-review` from the `<html>` tag on each page (find and replace `<html lang="en" data-review>` with `<html lang="en">`). All tags and placeholder logo slots then disappear.

## Before launch: content you need to supply

- **Studio and sign-in URLs**: `appUrl` / `signInUrl` in `assets/js/layout.js` (currently `/studio`; the "Start free", "Get started" and "Start creating" buttons in the HTML also point at `/studio`).
- **Contact form endpoint**: `formEndpoint` in `assets/js/layout.js`. Until set, the form shows a "not connected" message.
- **Trust & safety**: confirmed policy text for verification, likeness and consent, ownership, commercial use, content standards and watermarks.
- **FAQ answers** marked CONFIRM. Questions still to add from the old site: payment methods, credits per generation, annual plans, seats, two-factor, mobile app, projects and folders, account deletion.
- **Proof**: verify the three headline figures (106M+ generations, 14B+ views, 27,000+ creators) and add real customer logos / testimonials.
- **Developer API page**: the text comes from your live /developers page. Check the items tagged CONFIRM: intro wording, API reference URL, Developer API Terms link, the JavaScript/Python quickstarts and the Python webhook sample (only curl and Node.js were visible), and the trimmed `GET /v1/models` example. `GET /v1/tools/captions/{id}` was partly cut off in the recording.
- **Real media**: studio screenshot, avatar renders, showcase clips (see Adding media).
- **Legal**: paste the real Privacy and Terms.
- **Affiliate / referral content** (payouts, referral tracking) was on the old FAQ; it belongs on its own page, not the main FAQ.

## Logo and brand colour

- Logo: `assets/img/logo-mark.png` (header and footer) and `assets/img/favicon.png`. The supplied file is only 64×64, so it will look soft on large or high-density displays. Replace it with an SVG (preferred) or a 256px+ PNG keeping the same filename, or change the path in `assets/js/layout.js` (`MARK`) and the `<link rel="icon">` in each page.
- Accent colour: the logo's purples (`#7f56d9` and `#53389e`) set `--accent*` in `assets/css/tokens.css`. A lighter tint (`#9b7bea`) is used for text so it stays readable on the dark background.

## Notes

- Fonts load from Google Fonts. To self-host, drop the files in `assets/fonts/` and add `@font-face` rules to `tokens.css`.
- Header and footer are rendered by `layout.js`, so they are identical on every page. Without JavaScript they do not appear; if that matters for SEO, a small build step can inline them later.
- The site is dark only. There is no theme toggle.
